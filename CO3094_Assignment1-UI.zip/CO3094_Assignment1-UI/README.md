# UI
- Clone về sau đó mở terminal, chạy lệnh python3 server.py
- Sau đó nhập link sau trên browser http://127.0.0.1:5050
- Trong ô input On/Off gõ "on" và enter 
- Sau đó mở terminal thứ 2 và chạy lệnh python3 client.py
- Có được đường link và paste vào browser
- Nếu muốn chạy nhiều client cùng lúc thì thay đổi giá trị biến port cuối file client.py và chạy lệnh python3.py trong terminal -> paste link to broswer
- CLIENT:
      Thực hiện đăng nhập và đăng kí
      + PUBLISH: Sau đó nhất publish (lname: ta nhập đường dẫn file trong local disk và fname sau đó nhấn lại publish nên navbar để xem kết quả.
      Ví dụ: /home/yanzy/Downloads/Lab_4a_Wireshark_IP_v8.0 (1).pdf (*phải viết dấu '/') và fname trùng với tên file Lab_4a_Wireshark_IP_v8.0 (1).pdf
      + FETCH:  Thực hiện tương tự thao tác Publish sau đó check kết quả trong vscode  tại thư mục ./file-sharing
- SERVER:
      + PING: Tại ping nhập tên username muốn kiểm tra và nhấn ping sau đó click lại Ping trên thanh nav để xem kết quả
      + DISCOVER: Discover thực hiện tương tự ping


